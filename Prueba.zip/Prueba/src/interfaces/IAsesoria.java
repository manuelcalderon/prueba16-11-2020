/**
 * 
 */
package interfaces;

/**
 * @author Los Bucles
 *
 */
public interface IAsesoria {
	void analizarUsuario();
	//void AlmacenarCliente();

}

